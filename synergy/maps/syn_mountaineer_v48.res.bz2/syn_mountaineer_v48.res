"resources"
{
    "scripts/npc_sounds_gargantua.txt" "file"
}
